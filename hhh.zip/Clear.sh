clear
while true
do 
rm -rf /sdcard/Android/data/com.tencent.ig/files/cacheFile.txt
rm -rf /sdcard/Android/data/com.tencent.ig/files/login-identifier.txt
rm -rf /sdcard/Android/data/com.tencent.ig/cache
rm -rf /sdcard/Android/data/com.tencent.ig/files/tbslog
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /sdcard/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/cacheFile.txt
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/login-identifier.txt
rm -rf /sdcard/Android/data/com.pubg.krmobile/cache
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/tbslog
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora
rm -rf /src/main/java/com/google/errorprone/annotations
rm -rf /src/main/java/com/google/errorprone/annotations
rm -rf /src/main/java/com/google/errorprone/annotations/concurrent
rm -rf /third_party.java_src.error_prone.project.annotations.Google_internal
echo " deleting tencent log files .... "
sleep 60
done